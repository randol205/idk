const SECRET = '';
export default SECRET;
