which google-chrome-stable || sudo apt install google-chrome-stable
sudo apt-get install -f
sudo apt --fix-broken -y install

