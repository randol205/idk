parec -d auto_null.monitor | lame -r -V0 - out.mp3

