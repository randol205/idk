#!/usr/bin/env node

/* eslint-disable no-global-assign */
require = require('esm')(module/*, options*/);
module.exports = require('./render_static.js');
/* eslint-enable no-global-assign */
