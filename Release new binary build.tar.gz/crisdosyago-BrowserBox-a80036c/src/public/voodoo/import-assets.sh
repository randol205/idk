#!/bin/bash

cwd=$(pwd)
cd ./asset-imports/nhsuk-icons
./import.sh
cd $cwd


