export function takeShot(msg, state) {
  state.doShot();
}


