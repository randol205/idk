//import {DEBUG} from '../common.js';
import {d as R} from '../../node_modules/dumbass/r.js';

export function CopyModal(/*state*/) {
  return R`

  `;
}
