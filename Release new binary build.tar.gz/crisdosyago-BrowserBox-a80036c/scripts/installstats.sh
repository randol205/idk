sudo npm i -g sloc
sudo apt install cloc
