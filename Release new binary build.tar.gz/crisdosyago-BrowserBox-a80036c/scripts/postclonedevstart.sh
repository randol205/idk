npm i && npm test
