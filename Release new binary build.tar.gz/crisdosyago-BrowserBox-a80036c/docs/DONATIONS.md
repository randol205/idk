# Donation Links

Donate to ensure and help the development of VF Regular.

## Donation Options

**One time donations**

- [USD$399 one-time donation](https://buy.stripe.com/00g8xI0TngLhdagbJc)

- [USD$84.99 one-time donation](https://buy.stripe.com/9AQg0acC52Ur0nueVp)

**Regular donations**

- [USD84.99/mo donation](https://buy.stripe.com/8wM8xIdG97aHc6c7sY)

- [USD20/mo donation](https://buy.stripe.com/aEU7tEfOh66DgmsfZv)

